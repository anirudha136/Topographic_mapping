.. automodule:: scipy.misc
