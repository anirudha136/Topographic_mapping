
.. _continuous-kstwobign:

KStwo Distribution
==================

Implementation: `scipy.stats.kstwobign`
