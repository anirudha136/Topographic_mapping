.. automodule:: scipy.cluster.hierarchy
