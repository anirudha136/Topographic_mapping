.. _optimize.minimize-lbfgsb:

minimize(method='L-BFGS-B')
------------------------------------------

.. scipy-optimize:function:: scipy.optimize.minimize
   :impl: scipy.optimize.lbfgsb._minimize_lbfgsb
   :method: L-BFGS-B
