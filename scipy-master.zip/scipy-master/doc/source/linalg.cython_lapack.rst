.. automodule:: scipy.linalg.cython_lapack
